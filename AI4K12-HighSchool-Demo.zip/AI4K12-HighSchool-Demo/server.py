import os
import sys
from flask import Flask, render_template, request, jsonify

# Add /scripts folder to sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), "scripts"))

from scripts.app import process_submission, restart  # ✅ removed load_scenarios

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("home.html")

@app.route("/index/", methods=["GET", "POST"])
def index():
    if request.method == 'POST':
        restart()
    return render_template("index.html")

@app.route("/login/")
def base():
    return render_template("login.html")

@app.route("/modelpredictions/")
def modelpredictions():
    return render_template("model-predictions.html")

@app.route("/submit", methods=["POST"])
def submit_choice():
    data = request.json
    choice = data.get("choice")
    reason = data.get("reason")
    scenario = data.get("scenario")
    return jsonify(process_submission(choice, reason, scenario))

if __name__ == "__main__":
    app.run(debug=True)
